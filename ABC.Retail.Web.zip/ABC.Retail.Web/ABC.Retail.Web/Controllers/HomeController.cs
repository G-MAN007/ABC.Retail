//using ABC.Retail.Web.Models;
//using ABC.Retail.Web.Services;
//using Microsoft.AspNetCore.Mvc;
//using System.Diagnostics;

//namespace ABC.Retail.Web.Controllers
//{
//    public class HomeController : Controller
//    {
//        private readonly ILogger<HomeController> _logger;

//        public HomeController(ILogger<HomeController> logger)
//        {
//            _logger = logger;
//        }

//        public IActionResult Index()
//        {
//            return View();
//        }
//        [HttpPost]
//        public async Task<IActionResult> CreateCustomer(Customer customer)
//        {
//            customer.RowKey = Guid.NewGuid().ToString();
//            await _storageService.AddCustomerAsync(customer);
//            await _storageService.LogMessageAsync($"New customer created: {customer.CustomerName}");
//            return RedirectToAction("Index");
//        }

//        // Add these methods to HomeController.cs
//        [HttpPost]
//        public async Task<IActionResult> UploadImage(IFormFile file)
//        {
//            if (file != null)
//            {
//                await _storageService.UploadImageAsync(file.OpenReadStream(), file.FileName);
//                await _storageService.LogMessageAsync($"Image uploaded: {file.FileName}");
//            }
//            return RedirectToAction("Index");
//        }

//        // Add this method to HomeController.cs
//        [HttpPost]
//        public async Task<IActionResult> CreateOrder()
//        {
//            var orderMessage = $"Processing order for image: new-product.jpg, inventory update needed.";
//            await _storageService.AddOrderMessageAsync(orderMessage);
//            await _storageService.LogMessageAsync("Order message sent to queue.");
//            return RedirectToAction("Index");
//        }
//        public IActionResult Privacy()
//        {
//            return View();
//        }

//        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
//        public IActionResult Error()
//        {
//            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
//        }
//    }
//}


using ABC.Retail.Web.Models;
using ABC.Retail.Web.Services;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace ABC.Retail.Web.Controllers
{
    public class HomeController : Controller
    {
        // This line declares the private field to hold the storage service instance.
        // This is what was missing.
        private readonly StorageService _storageService;

        // The constructor now accepts the StorageService and assigns it to the private field.
        // This is how the service is "injected" into the controller.
        public HomeController(StorageService storageService)
        {
            _storageService = storageService;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> CreateCustomer(Customer customer)
        {
            if (ModelState.IsValid)
            {
                customer.RowKey = Guid.NewGuid().ToString();
                await _storageService.AddCustomerAsync(customer);
                await _storageService.LogMessageAsync($"New customer created: {customer.CustomerName}");
                return RedirectToAction("Index");
            }
            return View("Index", customer);
        }

        [HttpPost]
        public async Task<IActionResult> UploadImage(IFormFile file)
        {
            if (file != null && file.Length > 0)
            {
                await _storageService.UploadImageAsync(file.OpenReadStream(), file.FileName);
                await _storageService.LogMessageAsync($"Image uploaded: {file.FileName}");
            }
            return RedirectToAction("Index");
        }

        [HttpPost]
        public async Task<IActionResult> CreateOrder()
        {
            var orderMessage = $"Processing order requested at {DateTime.UtcNow:O}";
            await _storageService.AddOrderMessageAsync(orderMessage);
            await _storageService.LogMessageAsync("Order message sent to queue.");
            return RedirectToAction("Index");
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}