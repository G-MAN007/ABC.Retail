﻿using Azure.Data.Tables;
using Azure.Storage.Blobs;
using Azure.Storage.Queues;
using Azure.Storage.Files.Shares;
using ABC.Retail.Web.Models;
using System.Threading.Tasks;
using System.IO;

namespace ABC.Retail.Web.Services
{
    public class StorageService
    {
        private readonly TableClient _tableClient;
        private readonly BlobContainerClient _blobContainerClient;
        private readonly QueueClient _queueClient;
        private readonly ShareClient _shareClient;
        private readonly ShareDirectoryClient _directoryClient;

        public StorageService(IConfiguration configuration)
        {
            var connectionString = configuration.GetValue<string>("AzureStorageConfig:ConnectionString");
            _tableClient = new TableClient(connectionString, "CustomerProfiles");
            _tableClient.CreateIfNotExists();

            _blobContainerClient = new BlobContainerClient(connectionString, "productimages");
            _blobContainerClient.CreateIfNotExists();

            _queueClient = new QueueClient(connectionString, "orderprocessing");
            _queueClient.CreateIfNotExists();

            _shareClient = new ShareClient(connectionString, "logfiles");
            _shareClient.CreateIfNotExists();
            _directoryClient = _shareClient.GetDirectoryClient("");
        }

        // Customer (Table Storage) Methods
        public async Task<Customer> GetCustomerAsync(string rowKey)
        {
            return await _tableClient.GetEntityAsync<Customer>("Customer", rowKey);
        }

        public async Task AddCustomerAsync(Customer customer)
        {
            await _tableClient.AddEntityAsync(customer);
        }

        // Image (Blob Storage) Methods
        public async Task UploadImageAsync(Stream stream, string fileName)
        {
            var blobClient = _blobContainerClient.GetBlobClient(fileName);
            await blobClient.UploadAsync(stream, true);
        }

        // Order (Queue Storage) Method
        public async Task AddOrderMessageAsync(string message)
        {
            await _queueClient.SendMessageAsync(message);
        }

        // Logging (File Share) Method
        public async Task LogMessageAsync(string message)
        {
            var fileName = $"log-{DateTime.UtcNow:yyyy-MM-dd-HH-mm-ss}.txt";
            var fileClient = _directoryClient.GetFileClient(fileName);
            using (var stream = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(message)))
            {
                await fileClient.CreateAsync(stream.Length);
                await fileClient.UploadAsync(stream);
            }
        }
    }
}